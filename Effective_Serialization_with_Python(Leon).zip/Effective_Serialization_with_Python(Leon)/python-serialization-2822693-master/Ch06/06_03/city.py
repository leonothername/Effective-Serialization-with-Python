city = 'Köln'
query = 'Köln'
