-- SQL Example
CREATE TABLE IF NOT EXISTS logs (
    time TIMESTAMP,
    level VARCHAR(32),
    message TEXT
);
