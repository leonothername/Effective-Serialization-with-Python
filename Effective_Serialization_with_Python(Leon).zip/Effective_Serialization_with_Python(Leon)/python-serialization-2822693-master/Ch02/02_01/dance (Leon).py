"""Dance moves"""
from datetime import datetime, timedelta


class Dance:
    """Move is a dance move"""
    def __init__(self, time, limb, what):
        self.time = time
        self.limb = limb
        self.what = what

    def __repr__(self):
        cls = self.__class__.__name__
        return f'{cls}({self.time!r}, {self.limb!r}, {self.what!r})'


# Dance moves
second = timedelta(seconds=1)
now = datetime.now()
dance1 = Dance(now + 1*second, 'jump', 'to the left')
dance2 = Dance(now + 2*second, 'step', 'to the right')
dance3 = Dance(now + 3*second, 'hands', 'on your hips')
dance4 = Dance(now + 4*second, 'knees', 'bring in tight')
