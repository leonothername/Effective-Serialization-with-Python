"""Streaming pickle example"""
import pickle
from socket import socketpair

from dance_Leon import dance1, dance2, dance3, dance4, fight

ws, rs = socketpair()
w, r = ws.makefile('wb'), rs.makefile('rb')

# Serialize
pickle.dump(dance1, w)
pickle.dump(dance2, w)
pickle.dump(dance3, w)
pickle.dump(dance4, w)
pickle.dump(fight, w)
w.flush()

# De-serialize
for _ in range(5):
    dance = pickle.load(r)
    print(f'{dance.limb} {dance.what}')
