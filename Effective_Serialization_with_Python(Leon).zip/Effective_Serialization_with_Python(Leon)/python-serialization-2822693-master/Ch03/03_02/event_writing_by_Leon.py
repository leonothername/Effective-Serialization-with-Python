"""Shopping event"""
from datetime import datetime

event_writing_by_Leon = {
    'time': datetime(2020, 4, 17, 13, 27, 48),
    'name': 'Leon LYH',
    'item': 'Piano,  sword, and computer',
    'amount': 10,
    'item price': 4.75,
}
