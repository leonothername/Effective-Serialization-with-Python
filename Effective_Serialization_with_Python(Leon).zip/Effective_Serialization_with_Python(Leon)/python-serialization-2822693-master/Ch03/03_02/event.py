"""Shopping event"""
from datetime import datetime

event = {
    'time': datetime(2020, 4, 17, 13, 27, 48),
    'name': 'Homer',
    'item': 'Duff',
    'amount': 4,
    'item price': 4.75,
}
