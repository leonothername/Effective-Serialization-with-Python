"""Shopping event"""
event_create_by_Leon = {
    'name': 'Leon Lau Yat Howe',
    'item': 'Pencil',
    'amount': 4,
    'item price': 4.75,
}
