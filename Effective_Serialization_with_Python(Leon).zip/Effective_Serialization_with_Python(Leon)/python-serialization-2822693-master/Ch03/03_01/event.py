"""Shopping event"""
event = {
    'name': 'Homer Simpson',
    'item': 'Duff',
    'amount': 4,
    'item price': 4.75,
}
